require 'test_helper'

class SpecieTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
