require 'test_helper'

class WaterSensorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
