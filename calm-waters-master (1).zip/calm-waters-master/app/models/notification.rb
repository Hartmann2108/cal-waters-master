class Notification < ApplicationRecord
  belongs_to :tank
end