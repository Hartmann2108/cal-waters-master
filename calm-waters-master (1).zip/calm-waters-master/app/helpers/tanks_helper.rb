module TanksHelper
end
