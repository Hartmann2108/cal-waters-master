class SoloSensor < ApplicationRecord
  belongs_to :tank
end
