class WaterSensor < ApplicationRecord
  belongs_to :tank
end
