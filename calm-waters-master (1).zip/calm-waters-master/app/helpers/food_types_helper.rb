module FoodTypesHelper
end
