require 'test_helper'

class TankTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
