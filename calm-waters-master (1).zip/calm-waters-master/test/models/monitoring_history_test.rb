require 'test_helper'

class MonitoringHistoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
