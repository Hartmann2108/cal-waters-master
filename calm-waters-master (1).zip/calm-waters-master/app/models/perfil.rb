class Perfil < ApplicationRecord
  def to_s
    description
  end
end
