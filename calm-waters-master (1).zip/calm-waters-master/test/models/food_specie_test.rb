require 'test_helper'

class FoodSpecieTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
