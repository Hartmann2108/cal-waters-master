require 'test_helper'

class AmbientalConditionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
