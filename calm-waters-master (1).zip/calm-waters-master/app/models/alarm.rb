class Alarm < ApplicationRecord
  belongs_to :alarm_type
end